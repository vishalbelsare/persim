from .persim import PersImage

# Enable access to version number
import pkg_resources

__version__ = pkg_resources.get_distribution("persim").version
